

<form action="#user-friend" id="fave_button">
	<input type="submit" value="Add to faves" id="add_to_faves" class="pp_not_A_fave" />
	<input type="submit" value="A fave" title="Click to remove from faves" class="pp_A_fave" id="remove_from_faves" />
</form>