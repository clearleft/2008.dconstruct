<form action="#user-rating" id="addReview" title="Rate this">
	<label for="rating">Rating</label>
	<select name="rating" id="rating">
	<option>no rating</option>
	<option value="1" class="worst">*</option>
	<option value="2" class="bad">**</option>
	<option value="3" class="fair">***</option>
	<option value="4" class="good">****</option>
	<option value="5" class="best">*****</option>
	</select>
</form>