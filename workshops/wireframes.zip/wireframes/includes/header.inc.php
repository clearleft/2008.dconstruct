<div id="header">

<div id ="masthead">
	<h4><a href="/home.php">WebsiteName</a></h4>
</div><!-- /#masthead -->

<?php
$query = (isset($_REQUEST["query"]))?$_REQUEST["query"]:false; 
?>

<form action="/search/results.php" id="search">
	<div class="container">
		<label for="query">Search</label>
		<input name="query" id="query" type="text" />
		<input type="submit" value="Go" />
	</div>
</form>

<div id="nav-actions">
	<ul>
		<li><form action="/home.php#Logged_in" method="get"><button class="link"><span>Log out</span></button></form></li>
		<!--<li class="pp_not_Logged_in"><a href="/account/login.php">Log in</a></li>-->
	</ul>
</div>

<div id="nav-primary">
	<ul>
		<li id="nav-SectionOne"><a href="/section1/">Section One</a></li>
		<li id="nav-SectionTwo"><a href="/section2/">Section Two</a></li>
	</ul>

</div><!-- /#nav-primary -->

</div><!-- /#header -->
