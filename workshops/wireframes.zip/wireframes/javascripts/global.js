// Bespoke functions here

$(document).ready(
function() {

	// onReady jQuery stuff in here	
	
	$.polypage.init();
	$($.date_input.initialize);
	
	// fave button
	$('#add_to_faves').click(
		function() {
			$('#add_to_faves').fadeOut('slow');
			$('#remove_from_faves').fadeIn('slow');
			$.polypage.setState("A_fave", true);
			return false;
		}
	);
	$('#remove_from_faves').click(
		function() {
			$('#remove_from_faves').fadeOut('slow');
			$('#add_to_faves').fadeIn('slow');
			$.polypage.setState("A_fave", false)
			return false;
		}
	);

});


