<?php $dr = str_replace($_SERVER['SCRIPT_NAME'], '/includes/', $_SERVER['SCRIPT_FILENAME']); ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Page - WebsiteName: Section</title>
<?php include($dr . "headlinks.inc.php"); ?>
</head>

<body class="sectionone">

<?php include($dr . "header.inc.php"); ?>

<div id="maincontent">

<div class="t5 content">

<div class="secondary">
<p>Secondary content</p>
</div> <!-- /.secondary -->

<div class="primary">
<h1>Template 5</h1>

<!--<p class="pp_Notes">this is a note</p>-->
</div> <!-- /.primary -->

<div class="tertiary">
<p>Tertiary content</p>
</div> <!-- /.tertiary -->

</div> <!-- /.content -->

</div> <!-- /#maincontent -->

<?php include($dr . "footer.inc.php"); ?>

</body>
</html>
