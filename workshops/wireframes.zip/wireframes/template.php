<?php $dr = str_replace($_SERVER['SCRIPT_NAME'], '/includes/', $_SERVER['SCRIPT_FILENAME']); ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Page - WebsiteName: Section</title>
<?php include($dr . "headlinks.inc.php"); ?>
</head>

<body class="t2 sectionone">

<?php include($dr . "header.inc.php"); ?>

<div id="maincontent">

<div class="content">

<div class="primary">
<h1>Template with all includes and widgets</h1>

<?php include($dr . "starRating.inc.php"); ?>

<?php include($dr . "addToFaves.inc.php"); ?>

<form method="get" action="#">
<div class="text-container container">
	<label for="date">Date</label>
	<input type="text" id="date" name="date" class="small date_input" size="8" value="dd/mm/yy" />
</div>
</form>

<p>Lightboxed image <a href="images/pasta_fullsize.jpg" class="thickbox"><img src="images/pasta_medium.jpg" title="Nice pasta" /></a></p>
</div> <!-- /.primary -->

<div class="secondary">
<h3>Contacts</h3>
<?php include($dr . "contactlist.inc.php"); ?>


<h3>Groups</h3>
<?php include($dr . "grouplist.inc.php"); ?>


</div> <!-- /.secondary -->

</div> <!-- /.content -->

</div> <!-- /#maincontent -->

<?php include($dr . "footer.inc.php"); ?>

</body>
</html>
