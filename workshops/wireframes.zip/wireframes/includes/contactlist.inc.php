
<ul>
<li class="vcard">
	<a href="#" class="fn nickname url"><img class="photo" src="images/user_avatar.gif" alt="" />username</a>
	<span class="meta">meta</span>
</li>
<li class="vcard">
	<a href="#" class="fn nickname url">username</a>
	<span class="meta">meta</span>
</li>
<li class="vcard">
	<a href="#" class="fn nickname url"><img class="photo" src="images/user_avatar.gif" alt="" />username</a>
	<span class="meta">meta</span>
</li>
<li class="vcard">
	<a href="#" class="fn nickname url">username</a>
	<span class="meta">meta</span>
</li>
<li class="vcard">
	<a href="#" class="fn nickname url">username</a>
	<span class="meta">meta</span>
</li>
</ul>