<?php $dr = str_replace($_SERVER['SCRIPT_NAME'], '/includes/', $_SERVER['SCRIPT_FILENAME']); ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Website Wireframes</title>
<?php include($dr . "headlinks.inc.php"); ?>
</head>

<body id="index" class="prose">

<h1>Wireframes</h1>

<ul>
	<li>Section
		<ul>
			<li><a href="template.php">Page</a></li>
		</ul>
	</li>
</ul>

<h2>Templates</h2>


<ul>
	<li><a href="t0.php">T0 - 1 column, full width</a></li>
	<li><a href="t1.php">T1 - 2 columns, primary right</a></li>
	<li><a href="t2.php">T2 - 2 columns, primary left</a></li>
	<li><a href="t3.php">T3 - 2 columns, even width</a></li>
	<li><a href="t4.php">T4 - 3 columns, even width</a></li>
	<li><a href="t5.php">T5 - 3 columns, primary centre</a></li>
	<li><a href="t6.php">T6 - intro block followed by T2 and T4</a></li>
</ul>

<ul>
	<li><a href="harmonise_sample.html">Harmonise sampler</a></li>
	<li><a href="template.php">Template with all includes and widgets</a></li>
</ul>



</body>
</html>
