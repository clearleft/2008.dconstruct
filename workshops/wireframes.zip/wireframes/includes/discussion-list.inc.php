<tr>
	<td class="topic">
		<a href="profile.php"><img src="images/grey.gif" alt="Fran"/></a>
		<a href="#group-topic.php"><strong>Topic title</strong></a><br />
		by <a href="profile.php" class="user">Screen name of topic starter</a>
	</td>
	<td class="replies">2</td>
	<td class="lastpost">2 hours ago by  <a href="profile.php">Screen name</a></td>
</tr>
<tr>
	<td class="topic">
		<a href="profile.php"><img src="images/grey.gif" alt="Robert"/></a>
		<a href="#group-topic.php"><strong>What's better, shortcrust or puff pastry?</strong></a><br />
		by <a href="profile.php" class="user">Robert</a>
	</td>
	<td class="replies">5</td>
	<td class="lastpost">2 hours ago by  <a href="profile.php">Bob</a></td>
</tr>
<tr>
	<td class="topic">
		<a href="profile.php"><img src="images/grey.gif" alt="Weebl"/></a>
		<a href="#group-topic.php"><strong>Can pizza really be called a pie?</strong></a><br />
		by <a href="profile.php" class="user">Weebl</a>
	</td>
	<td class="replies">9</td>
	<td class="lastpost">2 hours ago by  <a href="profile.php">Chas n' Dave</a></td>
</tr>
<tr>
	<td class="topic">
		<a href="profile.php"><img src="images/grey.gif" alt="Clint"/></a>
		<a href="#group-topic.php"><strong>Rate my filling!!!!</strong></a><br />
		by <a href="profile.php" class="user">Clint</a>
	</td>
	<td class="replies">1</td>
	<td class="lastpost">2 hours ago by  <a href="profile.php">Krusty</a></td>
</tr>
<tr>
	<td class="topic">
		<a href="profile.php"><img src="images/grey.gif" alt="Weebl"/></a>
		<a href="#group-topic.php"><strong>Best recipe for steak and kidney</strong></a><br />
		by <a href="profile.php" class="user">Weebl</a>
	</td>
	<td class="replies">50</td>
	<td class="lastpost">2 hours ago by  <a href="profile.php">Bob</a></td>
</tr>