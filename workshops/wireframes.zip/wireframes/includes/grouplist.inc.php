<ul class="groups">
	<li>
		<a href="group.php"><img src="images/group_avatar.png" alt="group" class="photo" /> Group name</a>
		<span class="meta">meta</span>
	</li>
	<li>
		<a href="group.php"> Group name</a>
	</li>
	<li>
		<a href="group.php"><img src="images/group_avatar.png" alt="group" class="photo" /> Group name</a>
	</li>
</ul>	