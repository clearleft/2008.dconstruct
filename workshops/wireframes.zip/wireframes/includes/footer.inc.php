<div id="footer">
	<p>
	<a href="#">Terms &amp; conditions</a> &middot;
	<a href="#">Privacy</a> &middot;
	<a href="/about/contact.php">Contact us</a>
	</p>
	<address class="vcard">
	&copy; 2008 <span class="fn org">Company Name</span>,
	<span class="adr">
		<span class="extended-address">Office or apartment</span>,
		<span class="street-address">Street name and number</span>,
		<span class="locality">City or Town</span>,
		<span class="postal-code">POST CODE</span>,
		<abbr class="country-name" title="United Kingdom">UK</abbr>
	</span>
	</address>	
</div><!-- /footer -->
